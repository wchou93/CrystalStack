# -*- coding: utf-8 -*-
"""Build CrystalStack into a single-file Windows exe.

Run through build_exe.bat, which locates a usable Python and pauses at the end.
Everything PyInstaller needs is decided here so the exact command line used for
a release is recorded in one place instead of being retyped by hand.

The build uses a *separate* virtual environment (build_env) on purpose.  The
runtime .venv may sit next to unrelated packages -- matplotlib, pandas, a stray
cv2 -- and PyInstaller collects whatever it can import from the environment it
runs in, so building there silently ships all of that inside the exe.  A plain
venv has no system site-packages on sys.path, so only the pinned set below ends
up inside.  app.py / cif_io.py / layer_stacking.py / stacking_rules.py are
plain top-level modules living beside this file, hence --paths PROJ.

Usage:  python build_exe.py [--clean]
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time

PROJ = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(PROJ, "build_env")
VPY = os.path.join(VENV, "Scripts", "python.exe")
BUILD = os.path.join(PROJ, "build")
DIST = os.path.join(PROJ, "dist")
NAME = "CrystalStack"
EXE = os.path.join(DIST, NAME + ".exe")
REQ = os.path.join(PROJ, "requirements-build.txt")

# packages the program never touches; excluding them keeps the exe small and
# avoids dragging in a Qt toolkit or a notebook stack by accident
EXCLUDES = [
    "matplotlib", "pandas", "IPython", "jupyter", "notebook", "pytest",
    "PyQt5", "PyQt6", "PySide2", "PySide6", "tkinter",
]


def banner(msg: str) -> None:
    print("\n=== %s ===" % msg, flush=True)


def run(cmd: list[str], **kw) -> int:
    """Run a command, echoing it first so the log doubles as a record."""
    printable = " ".join(str(c) for c in cmd)
    print("   $", printable, flush=True)
    return subprocess.call([str(c) for c in cmd], **kw)


def ensure_venv() -> bool:
    """Create build_env if missing and make sure it has the pinned deps.

    Returns False when the environment cannot be brought to a usable state, so
    the caller can stop before PyInstaller runs and fails cryptically.
    """
    if not os.path.isfile(VPY):
        banner("creating build_env")
        if run([sys.executable, "-m", "venv", VENV]) != 0:
            print("   could not create build_env")
            return False

    banner("checking build dependencies")
    probe = ("import flask, numpy, scipy, PyInstaller, altgraph, pkg_resources")
    if run([VPY, "-c", probe], stdout=subprocess.DEVNULL,
           stderr=subprocess.DEVNULL) == 0:
        print("   build dependencies OK")
    else:
        print("   installing pinned build dependencies ...")
        if run([VPY, "-m", "pip", "install", "--disable-pip-version-check",
                "-q", "-r", REQ]) != 0:
            print("   dependency installation failed")
            return False
        if run([VPY, "-c", probe], stdout=subprocess.DEVNULL,
               stderr=subprocess.DEVNULL) != 0:
            print("   dependencies still missing after install")
            return False

    # The isolation guarantee the whole clean-venv approach rests on.  If this
    # ever prints False the exe is about to inherit the system site-packages.
    banner("verifying isolation")
    code = (
        "import sys;"
        "print('   prefix =', sys.prefix);"
        "print('   isolated =', 'build_env' in sys.prefix)"
    )
    run([VPY, "-c", code])
    return True


def preflight() -> bool:
    """Fail before the slow build if a data file is missing.

    --add-data silently produces an exe that raises Internal Server Error at
    request time instead of at build time, so its sources are checked here.
    """
    banner("preflight")
    needed = [
        os.path.join(PROJ, "app.py"),
        os.path.join(PROJ, "templates"),
        os.path.join(PROJ, "static"),
    ]
    ok = True
    for path in needed:
        if os.path.exists(path):
            print("   ok      %s" % os.path.relpath(path, PROJ))
        else:
            print("   MISSING %s" % path)
            ok = False
    if not ok:
        print("\nAborting: the exe would be built without its web resources.")
    return ok


def build() -> int:
    banner("running PyInstaller")
    for d in (BUILD, DIST):
        os.makedirs(d, exist_ok=True)

    cmd = [
        VPY, "-m", "PyInstaller",
        "--noconfirm", "--clean", "--onefile", "--console",
        "--name", NAME,
        # top-level project modules live next to this file
        "--paths", PROJ,
        # templates/ and static/ are *read* at runtime, never imported, so
        # PyInstaller's import analysis cannot see them
        "--add-data", "%s;templates" % os.path.join(PROJ, "templates"),
        "--add-data", "%s;static" % os.path.join(PROJ, "static"),
        # Flask's Jinja loader looks these up by path at runtime
        "--collect-all", "flask",
        "--collect-all", "jinja2",
        "--collect-all", "werkzeug",
        # scipy pulls numpy and its own subpackages in through dynamic paths
        # (scipy._external.array_api_compat.* is imported by name at runtime),
        # which import analysis misses -- without these the exe dies on startup
        "--collect-all", "scipy",
        "--collect-all", "numpy",
        "--hidden-import", "layer_stacking",
        "--hidden-import", "stacking_rules",
        "--hidden-import", "cif_io",
    ]
    for mod in EXCLUDES:
        cmd += ["--exclude-module", mod]

    # absolute paths throughout: with --specpath set, relative --add-data
    # sources are resolved against the spec directory and the build fails with
    # "Unable to find ... when adding binary and data files"
    cmd += [
        "--distpath", DIST,
        "--workpath", BUILD,
        "--specpath", BUILD,
        os.path.join(PROJ, "app.py"),
    ]

    rc = run(cmd, cwd=PROJ)
    if rc != 0:
        print("\nPyInstaller exited with %d" % rc)
    return rc


def verify() -> bool:
    """Do not trust the exit code alone -- assert the artefact is really there."""
    banner("verifying")
    if not os.path.isfile(EXE):
        print("   MISSING %s" % EXE)
        return False
    size_mb = os.path.getsize(EXE) / 1048576
    print("   %s  %.1f MB" % (EXE, size_mb))
    if size_mb < 10:
        print("   suspiciously small -- did the data files get bundled?")
        return False
    return True


def cleanup() -> None:
    banner("cleaning intermediates")
    for d in (BUILD, VENV):
        if os.path.isdir(d):
            shutil.rmtree(d, ignore_errors=True)
            print("   removed %s" % os.path.basename(d))
    log = os.path.join(PROJ, "build_log.txt")
    if os.path.isfile(log):
        os.remove(log)


def main() -> int:
    keep = "--clean" not in sys.argv
    t0 = time.time()
    print("CrystalStack exe builder")
    print("project: %s" % PROJ)

    if not preflight():
        return 1
    if not ensure_venv():
        print("\nAborting: the build environment is not usable.")
        return 1
    if build() != 0:
        return 1
    if not verify():
        return 1

    print("\nBuild finished in %.0f s" % (time.time() - t0))
    print("artefact: %s" % EXE)
    if keep:
        cleanup()
        print("Re-run with --clean to keep build_env/ and build/ for a faster "
              "rebuild.")
    else:
        print("build_env/ and build/ kept (--clean).")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\ninterrupted")
        sys.exit(130)