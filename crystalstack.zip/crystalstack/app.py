# -*- coding: utf-8 -*-
"""2D layer-stacking generator -- Flask web front end.

Takes a single-layer structure file (a CIF) and writes the five stacking
arrangements that appear in the layer-alignment paper:

============  ==========================================  ==========
mode          geometry                                    atoms
============  ==========================================  ==========
eclipsed      zero offset, AA stacking                    conserved
inclined      c vector tilted, fractional coords kept     conserved
serrated      c doubled, every other layer slipped        doubled
staggered     c doubled, layer over the pore centre       doubled
rotated       c doubled, layer-2 = symmetry op(layer-1)   doubled
============  ==========================================  ==========

``rotated`` is the rotation / mirror family.  Its second layer is produced
by applying a symmetry operation (a transposition by default) to the first
layer rather than by an in-plane translation.

This application produces the structures and nothing else -- no images.
The manuscript's structure figures are drawn by make_figure3.py (and
Figure 1 by make_algorithm_figure.py), both of which use Matplotlib and
ship with the source; VESTA is what a *user* opens the outputs in, and
is not part of this pipeline.
"""

from __future__ import annotations

import os
import tempfile
import zipfile
from datetime import datetime

import numpy as np
from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    send_from_directory,
    session,
    url_for,
)

from layer_stacking import (
    MODE_LABELS,
    STACKING_MODES,
    LayerStackingEngine,
)
from cif_io import Structure, read_cif, write_cif
from stacking_rules import DEFAULT_SYMMETRY_OP, SYMMETRY_OPS

# ---------------------------------------------------------------------- #
# application setup
# ---------------------------------------------------------------------- #
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs")
#: No extension filter.  The picker offers every file and the server takes any
#: name it is given: a structure deposited in a database is often exported as
#: ``deposition_1234567.cif`` or carries no extension at all.  The parser is
#: the real validator -- it reports the missing ``_cell_length_a`` tag, the
#: absent atom-site loop or the line it could not read -- so filtering by name
#: only turns valid inputs away and lets invalid ones through.
MAX_FILE_SIZE = 16 * 1024 * 1024

#: The modes produced by default; the user may add eclipsed and rotated.
DEFAULT_MODES = ("inclined", "serrated", "staggered")

app = Flask(__name__)
app.secret_key = os.environ.get("LAYER_STACKING_SECRET", "layer-stacking-2d")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE
# Jinja caches compiled templates unless told otherwise, and with debug=False
# that cache never expires -- so editing templates/*.html while the server runs
# changes nothing on refresh, which reads as "my edit did nothing".  The
# stylesheet is read from disk per request and updates either way, so the
# symptom is a page whose CSS is current and whose markup is not.
app.config["TEMPLATES_AUTO_RELOAD"] = True

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)


# ---------------------------------------------------------------------- #
# translations
# ---------------------------------------------------------------------- #
TRANSLATIONS = {
    "en": {
        "nav_brand": "2D Layer Stacking",
        "index_title": "Upload a monolayer structure",
        "index_intro": "Upload a CIF holding a single layer. The program "
                       "builds the eclipsed, inclined, serrated, staggered "
                       "and rotated arrangements from it.",
        "upload_label": "Crystallographic information file (CIF)",
        "upload_btn": "Upload",
        "choose_btn": "Choose file",
        "no_file_chosen": "No file chosen",
        "parameter_title": "Stacking parameters",
        "modes_label": "Stacking modes to generate",
        "mode_eclipsed": "Eclipsed AA (zero offset)",
        "mode_inclined": "Inclined AA (tilted c vector)",
        "mode_serrated": "Serrated AA (slipped stack)",
        "mode_staggered": "Staggered AB (over pore centre)",
        "mode_rotated": "Rotated / mirrored (symmetry operation)",
        "symmetry_label": "Symmetry operation (rotated mode)",
        "symmetry_hint": "Layer 2 is built by applying this operation to "
                         "layer 1, then shifting it by half the doubled c "
                         "axis. The transposition is the operation fitted to "
                         "the reference bilayer.",
        "symmetry_transpose": "transpose (x<->y)",
        "symmetry_identity": "identity (pure translation)",
        "symmetry_inversion": "inversion",
        "symmetry_mirror_x": "mirror x",
        "symmetry_mirror_y": "mirror y",
        "symmetry_rot120": "rotation 120 deg",
        "symmetry_rot180": "rotation 180 deg",
        "symmetry_col": "Symmetry",
        "symmetry_none": "—",
        "offset_mode_label": "In-plane offset",
        "offset_auto": "Determine automatically",
        "offset_manual": "Enter manually",
        "offset_hint": "Two values. Both at most 1 are read as fractional "
                       "coordinates of a and b; larger values as angstroms.",
        "offset_fx": "fraction along a",
        "offset_fy": "fraction along b",
        "interlayer_label": "Interlayer spacing d (Å, optional)",
        "interlayer_hint": "Leave empty to use the c length of the input.",
        "generate_btn": "Generate structures",
        "result_title": "Generated structures",
        "result_intro": "Load these files into VESTA to view the structures.",
        "lattice_label": "In-plane cell",
        "atoms_label": "Atoms",
        "offset_label": "Offset",
        "quality_label": "Min. separation",
        "source_label": "Offset source",
        "tilt_label": "c tilt (deg)",
        "c_length_label": "c (Å)",
        "download_btn": "Download",
        "download_zip_btn": "Download all (ZIP)",
        "back_btn": "Back",
        "individual_files_label": "Individual files",
        "mode_col": "Mode",
        "source_auto": "automatic",
        "source_manual": "manual",
        "source_input": "from input",
        "source_symmetry": "symmetry",
        "source_default": "conventional value",
        "source_geometric": "geometric search",
        "source_reference": "reference cell",
        "source_reference_named": "reference cell (%s)",
        "source_unverified": "rule - please verify",
        "warning_unverified": "The in-plane offset for this framework was taken "
                              "from the conventional rule, but its slip "
                              "direction could not be confirmed from the "
                              "monolayer alone. Enter a measured offset below "
                              "if you have one.",
        "input_summary_title": "Input structure",
        "lattice_type_label": "Lattice type",
        "error_no_file": "Please choose a file first.",
        "error_parse": "Could not read the structure: ",
        "error_no_modes": "Select at least one stacking mode.",
        "error_stale": "The uploaded structure expired; please upload it again.",
        "error_generic": "Something went wrong: ",
        "warning_multilayer": "The input holds more than one layer; only the "
                              "first was used.",
        "warning_bilayer_split": "The input is a bilayer. It was reduced to a "
                                 "single layer before the operation was "
                                 "re-applied.",
        "note_cif_format": "Every generated structure is written as a CIF, "
                           "which any crystallographic viewer can open.",
    },
}
TRANSLATIONS["zh"] = TRANSLATIONS["en"]  # English-only build; alias kept so stale "zh" sessions still resolve


def get_lang() -> str:
    return session.get("lang", "en")


def translate(key: str) -> str:
    return TRANSLATIONS.get(get_lang(), TRANSLATIONS["en"]).get(key, key)


@app.context_processor
def inject_translations():
    lang = get_lang()
    table = TRANSLATIONS.get(lang, TRANSLATIONS["en"])

    def _(key: str) -> str:
        return table.get(key, key)

    return {"_": _, "lang": lang, "other_lang": "en" if lang == "zh" else "zh"}


@app.route("/set_language/<lang>")
def set_language(lang: str):
    if lang in TRANSLATIONS:
        session["lang"] = lang
    return redirect(request.referrer or url_for("index"))


# ---------------------------------------------------------------------- #
# helpers
# ---------------------------------------------------------------------- #
def _workdir() -> str:
    """A fresh per-run output directory."""
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    path = os.path.join(OUTPUT_FOLDER, "run-" + stamp)
    os.makedirs(path, exist_ok=True)
    return path


def _source_label(source: str) -> str:
    if source.startswith("reference:"):
        return "source_reference"
    return {
        "auto": "source_auto",
        "manual": "source_manual",
        "input": "source_input",
        "symmetry": "source_symmetry",
        "default": "source_default",
        "rule (unverified)": "source_unverified",
        "geometric": "source_geometric",
    }.get(source, source)


def _source_detail(source: str) -> str:
    """Human-readable rendering of an offset source string."""
    if source.startswith("reference:"):
        return TRANSLATIONS.get(get_lang(), TRANSLATIONS["en"]).get("source_reference_named", "matched %s") % \
            source.split(":", 1)[1]
    return source


def _parse_float(raw: str):
    try:
        return float(str(raw).strip())
    except (TypeError, ValueError):
        return None


#: Keys of the symmetry operations offered for the ``rotated`` mode.
SYMMETRY_KEYS = tuple(key for key, _label, _mat in SYMMETRY_OPS)
SYMMETRY_LABELS = {key: label for key, label, _mat in SYMMETRY_OPS}


def _symmetry_label(key: str) -> str:
    """Localised display label for a symmetry-operation key."""
    if not key:
        return ""
    return translate("symmetry_" + key) if key in SYMMETRY_LABELS else key


# ---------------------------------------------------------------------- #
# routes
# ---------------------------------------------------------------------- #
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/configure", methods=["POST"])
def configure():
    """Step 2 -- receive the upload and offer the parameters."""
    upload = request.files.get("structure_file")
    if upload is None or not upload.filename:
        flash(translate("error_no_file"), "error")
        return redirect(url_for("index"))

    raw = upload.read()
    tmp = tempfile.NamedTemporaryFile(
        mode="wb", suffix="_" + os.path.basename(upload.filename),
        delete=False, dir=UPLOAD_FOLDER,
    )
    tmp.write(raw)
    tmp.close()

    try:
        structure = read_cif(tmp.name)
    except Exception as exc:  # noqa: BLE001 - reported to the user
        flash(translate("error_parse") + str(exc), "error")
        return redirect(url_for("index"))

    # A single-layer input is required.  Two situations collapse to one:
    # a genuine bilayer (two identical complete monolayers, e.g. the
    # reference bilayer) and any other multilayer stack -- in both cases we
    # keep one layer and tell the user.
    engine = LayerStackingEngine(structure)
    warning = None
    if engine.n_layers > 1:
        if engine.is_bilayer():
            # Reduces to one layer while keeping the per-species counts
            # consistent -- reuses the same tested helper as mode (e).
            structure = engine.effective_monolayer().structure
            warning = translate("warning_bilayer_split")
        else:
            groups = structure.layer_groups()
            keep = np.sort(np.concatenate(groups[:1]))
            counts = [
                int(np.sum(np.asarray(structure.species_per_atom)[keep] == sym))
                for sym in structure.species
            ]
            structure = Structure(
                lattice=structure.lattice,
                species=list(structure.species),
                counts=counts,
                frac_coords=structure.frac_coords[keep],
                title=structure.title,
            )
            warning = translate("warning_multilayer")
        engine = LayerStackingEngine(structure)

    if warning:
        flash(warning, "warning")

    session["structure"] = structure.to_dict()
    session["source_name"] = os.path.basename(upload.filename)

    return redirect(url_for("configure_panel"))


@app.route("/configure")
def configure_panel():
    """Step 2 (GET) -- the parameter form."""
    if "structure" not in session:
        flash(translate("error_stale"), "error")
        return redirect(url_for("index"))

    structure = Structure.from_dict(session["structure"])
    engine = LayerStackingEngine(structure)

    return render_template(
        "configure.html",
        default_modes=list(DEFAULT_MODES),
        modes=STACKING_MODES,
        symmetry_keys=list(SYMMETRY_KEYS),
        default_symmetry=DEFAULT_SYMMETRY_OP,
        source_name=session.get("source_name", "input"),
        natoms=structure.natoms,
        formula=structure.formula,
        lattice_type=engine.lattice_type,
        abc=[round(float(x), 4) for x in structure.abc],
        offset_ambiguous=engine.aa_is_ambiguous(),
        is_bilayer=engine.is_bilayer(),
    )


@app.route("/process", methods=["POST"])
def process():
    """Step 3 -- build the selected configurations."""
    if "structure" not in session:
        flash(translate("error_stale"), "error")
        return redirect(url_for("index"))

    try:
        structure = Structure.from_dict(session["structure"])
        engine = LayerStackingEngine(structure)

        modes = [m for m in request.form.getlist("modes") if m in STACKING_MODES]
        if not modes:
            flash(translate("error_no_modes"), "error")
            return redirect(url_for("configure_panel"))
        # Keep a deterministic, physically sensible order.
        modes = [m for m in STACKING_MODES if m in modes]

        # --- optional manual offset -------------------------------------
        manual_offset = None
        offset_fx = _parse_float(request.form.get("offset_fx", ""))
        offset_fy = _parse_float(request.form.get("offset_fy", ""))
        if offset_fx is not None and offset_fy is not None:
            manual_offset = [offset_fx, offset_fy]
            if manual_offset == [0.0, 0.0]:
                manual_offset = None

        d_raw = _parse_float(request.form.get("interlayer", ""))
        interlayer = d_raw if (d_raw and d_raw > 0) else None

        # --- symmetry operation for the rotated mode ---------------------
        symmetry = request.form.get("symmetry", "") or DEFAULT_SYMMETRY_OP
        if symmetry not in SYMMETRY_KEYS:
            symmetry = DEFAULT_SYMMETRY_OP

        # A manual offset cannot be shared between serrated and staggered,
        # so when both are requested the manual value applies to the slipped
        # modes and the pore-centre search still runs for the staggered one.
        doubled = [m for m in modes if m in ("serrated", "staggered")]
        shareable = manual_offset is not None and len(doubled) <= 1

        working = _workdir()
        records = []
        for mode in modes:
            use_offset = manual_offset if (mode != "staggered" or shareable) else None
            if mode == "inclined":
                use_offset = manual_offset
            if mode == "rotated":
                result = engine.build(mode, symmetry=symmetry,
                                      interlayer_distance=interlayer)
            else:
                result = engine.build(mode, use_offset, interlayer)

            # Every arrangement is written as a CIF.  The rotated family keeps
            # the symmetry operation in the file name, so a run that generates
            # it alongside the others stays unambiguous.
            if mode == "rotated":
                filename = "rotated-%s.cif" % symmetry
            else:
                filename = "%s.cif" % mode
            path = os.path.join(working, filename)
            write_cif(
                result.structure, path,
                title="%s | %s" % (MODE_LABELS[mode],
                                   session.get("source_name", "")),
            )
            summary = result.summary()
            summary.update({
                "filename": filename,
                "relpath": os.path.relpath(path, OUTPUT_FOLDER).replace("\\", "/"),
                "source_key": _source_label(str(summary["offset_source"])),
                "abc": [round(float(x), 4) for x in result.structure.abc],
                "formula": result.structure.formula,
                "symmetry_label": _symmetry_label(
                    getattr(result, "symmetry_op", "")
                ),
            })
            records.append(summary)

        zpath = os.path.join(working, "layer_stacking.zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for rec in records:
                zf.write(os.path.join(working, rec["filename"]), rec["filename"])

        session["last_run"] = os.path.relpath(working, OUTPUT_FOLDER).replace("\\", "/")

        return render_template(
            "result.html",
            records=records,
            run_dir=session["last_run"],
            lattice_type=engine.lattice_type,
            abc=[round(float(x), 4) for x in structure.abc],
            natoms=structure.natoms,
            formula=structure.formula,
            source_name=session.get("source_name", "input"),
            has_rotated=any(r["mode"] == "rotated" for r in records),
            symmetry_label=_symmetry_label(symmetry),
            was_bilayer=engine.is_bilayer(),
        )

    except Exception as exc:  # noqa: BLE001 - reported to the user
        flash(translate("error_generic") + str(exc), "error")
        return redirect(url_for("configure_panel"))


@app.route("/download/<path:relpath>")
def download(relpath: str):
    return send_from_directory(OUTPUT_FOLDER, relpath, as_attachment=True)


@app.route("/download_zip")
def download_zip():
    run = session.get("last_run")
    if not run:
        flash(translate("error_stale"), "error")
        return redirect(url_for("index"))
    path = os.path.join(OUTPUT_FOLDER, run, "layer_stacking.zip")
    if not os.path.isfile(path):
        flash(translate("error_stale"), "error")
        return redirect(url_for("index"))
    return send_file(path, as_attachment=True, download_name="layer_stacking.zip")


def _port_is_busy(port: int) -> bool:
    """Is something already serving on 127.0.0.1:``port``?

    Two checks, and both are needed on Windows.  A *connect* finds anything
    that is listening.  A *bind* catches the rest -- and it must not ask for
    ``SO_REUSEADDR``, because on Windows that flag lets a second socket bind
    a port that is already in use, which is exactly how a probe ends up
    reporting a busy port as free.  (Werkzeug sets the flag too, so two
    servers can silently share one port and answer only half the requests.)
    """
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.4)
        if probe.connect_ex(("127.0.0.1", port)) == 0:
            return True
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        try:
            probe.bind(("127.0.0.1", port))
        except OSError:
            return True
    return False


def _free_port(preferred: int, tries: int = 10) -> int:
    """The first port at or after ``preferred`` that nothing is using.

    A hard-coded 5000 is a poor default: it is also the AirPlay receiver port
    and is commonly taken, and ``app.run`` then dies with a bare ``OSError``
    that says nothing useful to someone who just double-clicked a launcher.
    Probing first turns that into a one-line message naming the port used
    instead.
    """
    for port in range(preferred, preferred + tries):
        if not _port_is_busy(port):
            return port
    raise SystemExit(
        "no free port in %d-%d; set LAYER_STACKING_PORT to choose another"
        % (preferred, preferred + tries - 1))


def _open_browser_when_ready(url: str, timeout: float = 60.0) -> None:
    """Wait until the server accepts connections, then open ``url``.

    The launcher used to open the browser and only then start serving, so the
    first thing the user saw was "can't reach this page" -- Flask needs a
    moment to import NumPy, SciPy and the engine before it listens.
    """
    import socket
    import threading
    import time
    import webbrowser

    port = int(url.rsplit(":", 1)[1].rstrip("/"))

    def wait() -> None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.settimeout(0.4)
                if probe.connect_ex(("127.0.0.1", port)) == 0:
                    webbrowser.open(url)
                    return
            time.sleep(0.25)
        print("browser not opened: the server did not come up within %.0f s"
              % timeout)

    threading.Thread(target=wait, daemon=True).start()


def main() -> None:
    """Start the development server.

    ``LAYER_STACKING_PORT`` picks the preferred port (5000 by default, taken
    over by the next free one if it is busy) and
    ``LAYER_STACKING_OPEN_BROWSER=1`` opens it once the server answers -- that
    is what run_webapp.bat sets, while a hand-run ``python app.py`` stays
    quiet as before.
    """
    preferred = int(os.environ.get("LAYER_STACKING_PORT", "5000"))
    port = _free_port(preferred)
    url = "http://127.0.0.1:%d" % port
    if port != preferred:
        print("port %d was busy; using %d instead" % (preferred, port))
    print("serving %s  (stop with Ctrl+C)" % url)
    if os.environ.get("LAYER_STACKING_OPEN_BROWSER") == "1":
        _open_browser_when_ready(url)
    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    main()
