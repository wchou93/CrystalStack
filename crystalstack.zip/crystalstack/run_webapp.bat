@echo off
rem =====================================================================
rem  CrystalStack 2D Layer Stacking -- Windows launcher
rem
rem  Plain ASCII on purpose: cmd.exe parses a .bat file in the console's
rem  ANSI codepage, so non-ASCII text gets mis-decoded. Keep CRLF endings.
rem =====================================================================
title CrystalStack - 2D Layer Stacking
cd /d "%~dp0"

echo ============================================
echo   CrystalStack - 2D Layer Stacking Web UI
echo ============================================
echo.

rem ---- 1. interpreter ------------------------------------------------
rem Do not trust "where python": on Windows 10/11 that also finds the
rem Microsoft Store stub, which exists but cannot create a virtualenv.
set "PY="
for %%P in (py python python3) do (
    if not defined PY (
        %%P -c "import sys; raise SystemExit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
        if not errorlevel 1 set "PY=%%P"
    )
)
if not defined PY (
    echo [1/3] Error: Python 3.10 or newer not found on PATH.
    echo       Install it from https://www.python.org/downloads/ and
    echo       tick "Add python.exe to PATH" during setup.
    echo.
    pause
    exit /b 1
)

rem ---- 2. virtual environment ---------------------------------------
if exist ".venv\Scripts\python.exe" (
    echo [1/3] Virtual environment found  ^(.venv^)
) else (
    echo [1/3] No virtual environment detected, creating .venv ...
    where uv >nul 2>nul
    if not errorlevel 1 (
        rem --seed: a bare "uv venv" ships without pip, which breaks the
        rem dependency step below.
        uv venv --seed .venv
    ) else (
        %PY% -m venv .venv
    )
    if not exist ".venv\Scripts\python.exe" (
        echo.
        echo [1/3] Error: could not create .venv.
        pause
        exit /b 1
    )
)

rem ---- 3. dependencies ----------------------------------------------
".venv\Scripts\python.exe" -c "import flask, scipy, numpy" >nul 2>nul
if not errorlevel 1 (
    echo [2/3] Dependencies OK  ^(flask / scipy / numpy^)
    goto serve
)

echo [2/3] Installing dependencies, this can take a minute on first run ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo       Default index failed, retrying via Tsinghua mirror ...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
)
".venv\Scripts\python.exe" -c "import flask, scipy, numpy" >nul 2>nul
if errorlevel 1 (
    echo.
    echo [2/3] Error: dependency installation failed, check your network.
    pause
    exit /b 1
)

:serve
rem ---- 4. serve -----------------------------------------------------
rem app.py takes the next free port if 5000 is busy, and -- because of the
rem flag below -- opens the browser only once it is actually answering.
set "LAYER_STACKING_OPEN_BROWSER=1"
echo [3/3] Starting the server, your browser will open automatically ...
echo       Close this window or press Ctrl+C to stop.
echo.
".venv\Scripts\python.exe" app.py

echo.
echo Server stopped.
pause
