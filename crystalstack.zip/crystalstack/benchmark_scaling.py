# -*- coding: utf-8 -*-
"""Scaling benchmark for the layer-stacking construction.

Builds supercells of the four benchmark monolayers and times the complete
pipeline -- CIF parse, layer analysis, offset determination, construction
of every mode and the structure write -- exactly as the web application runs
it.  The point of the script is to make the "tens of thousands of atoms"
claim in the manuscript reproducible: the numbers it prints are the ones the
paper quotes, together with the machine they were measured on.

Run::

    layer_stacking_web/.venv/Scripts/python.exe benchmark_scaling.py

``--repeats N`` (default 3) sets how often each configuration is timed.  Every
repeat is kept: the table reports mean +- population standard deviation per
stage (parse, build, write, total), and the process's peak working set, which
is what the manuscript's Table S11 quotes.
"""
from __future__ import annotations

import argparse
import os
import platform
import statistics
import sys
import time
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from layer_stacking import LayerStackingEngine  # noqa: E402
from cif_io import Structure, read_cif, write_cif  # noqa: E402

DATA = os.path.join(HERE, "reference")
MODES = ("eclipsed", "inclined", "serrated", "staggered")
SYSTEMS = ("COF-1", "COF-5", "CTF-1", "Pc-PBBA")


def supercell(structure: Structure, n: int) -> Structure:
    """``n x n x 1`` supercell of a monolayer."""
    a, b = structure.lattice[0], structure.lattice[1]
    lat = structure.lattice.copy()
    lat[0] = a * n
    lat[1] = b * n
    fracs, species = [], []
    per_atom = structure.species_per_atom
    for i in range(n):
        for j in range(n):
            f = structure.frac_coords.copy()
            f[:, 0] = (f[:, 0] + i) / n
            f[:, 1] = (f[:, 1] + j) / n
            fracs.append(f)
            species.extend(per_atom)
    frac = np.vstack(fracs)
    # re-group the atoms into species blocks
    order = np.argsort(np.array(species), kind="stable")
    order = np.concatenate([np.where(np.array(species) == s)[0]
                            for s in structure.species])
    out = Structure(
        lattice=lat,
        species=list(structure.species),
        counts=[c * n * n for c in structure.counts],
        frac_coords=frac[order],
        title=structure.title,
    )
    return out


def time_once(structure: Structure, outdir: str) -> dict:
    """One full pass; returns the wall time of each stage in seconds."""
    t0 = time.perf_counter()
    engine = LayerStackingEngine(structure)
    n_layers = engine.n_layers
    t1 = time.perf_counter()
    results = {m: engine.build(m) for m in MODES}
    t2 = time.perf_counter()
    written = []
    for m, res in results.items():
        path = os.path.join(outdir, "%s.cif" % m)
        write_cif(res.structure, path)
        written.append(path)
    t3 = time.perf_counter()
    # the application hands the user a single archive, so the zip is part of
    # the wait and is timed with the rest
    with zipfile.ZipFile(os.path.join(outdir, "layer_stacking.zip"), "w",
                         zipfile.ZIP_DEFLATED) as zf:
        for path in written:
            zf.write(path, os.path.basename(path))
    t4 = time.perf_counter()
    return dict(setup=t1 - t0, build=t2 - t1, write=t3 - t2, zip=t4 - t3,
                total=t4 - t0, n_layers=n_layers,
                natoms_out=sum(r.structure.natoms for r in results.values()))


def cpu_name() -> str:
    """Human-readable processor name; ``platform.processor()`` is useless here.

    Windows reports the bare family/model/stepping ("Intel64 Family 6 Model
    165 Stepping 3"), which identifies no purchasable part, so the registry
    string is read instead.  Elsewhere the platform string is used as-is.
    """
    if platform.system() == "Windows":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            return winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
        except OSError:
            pass
    return platform.processor() or platform.machine()


def memory_gb() -> float:
    """Installed RAM in GB, or 0.0 when it cannot be read.

    ``os.sysconf`` does not exist on Windows and ``platform`` exposes no
    memory at all, so the Win32 ``GlobalMemoryStatusEx`` call is used there.
    The figure is context for the timings, not something the benchmark
    depends on.
    """
    if platform.system() == "Windows":
        try:
            import ctypes

            class _MemStatus(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            stat = _MemStatus()
            stat.dwLength = ctypes.sizeof(_MemStatus)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
                return stat.ullTotalPhys / 1024 ** 3
        except (OSError, AttributeError, ValueError):
            pass
        return 0.0
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024 ** 3
    except (AttributeError, ValueError, OSError):
        return 0.0


def working_set_gb() -> float:
    """This process's working set (resident memory) in GB, or 0.0.

    The reviewer asked for the memory the benchmark actually needs, which is
    not the machine's installed RAM: ``GetProcessMemoryInfo`` reports what the
    interpreter is holding.  Its ``PeakWorkingSetSize`` is a high-water mark
    for the process lifetime, which is what a scaling table wants -- by the
    last, largest configuration it is the memory that case required.
    """
    if platform.system() != "Windows":
        try:
            import resource
            return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 ** 2
        except (ImportError, ValueError):
            return 0.0
    try:
        import ctypes
        import ctypes.wintypes as wt

        class _Counters(ctypes.Structure):
            _fields_ = [("cb", wt.DWORD),
                        ("PageFaultCount", wt.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t),
                        ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t),
                        ("PeakPagefileUsage", ctypes.c_size_t)]

        # K32GetProcessMemoryInfo, not psapi.GetProcessMemoryInfo: same call,
        # already in kernel32 on Vista and later.  The argtypes/restype are not
        # optional -- without them ctypes passes the pseudo-handle as a 32-bit
        # int, the call fails, and the function silently reports 0.000 GB.
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        get_handle = k32.GetCurrentProcess
        get_handle.restype = wt.HANDLE
        get_info = k32.K32GetProcessMemoryInfo
        get_info.argtypes = [wt.HANDLE, ctypes.POINTER(_Counters), wt.DWORD]
        get_info.restype = wt.BOOL

        c = _Counters()
        c.cb = ctypes.sizeof(_Counters)
        if get_info(get_handle(), ctypes.byref(c), c.cb):
            return c.PeakWorkingSetSize / 1024 ** 3
    except (OSError, AttributeError, ValueError):
        pass
    return 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--outdir", default=os.path.join(HERE, "outputs", "benchmark"))
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    print("machine   : %s %s" % (platform.system(), platform.release()))
    print("processor : %s, %d threads" % (cpu_name(), os.cpu_count() or 0))
    print("memory    : %.1f GB" % memory_gb())
    print("python    : %s %s" % (platform.python_version(), platform.python_implementation()))
    print("numpy     : %s" % np.__version__)
    print("repeats   : %d (mean +- population standard deviation)" % args.repeats)
    print()
    print("%-9s %5s %8s %9s %9s %9s %9s %9s %8s"
          % ("system", "n x n", "natoms", "parse(s)", "build(s)", "write(s)",
             "zip(s)", "total(s)", "peak GB"))
    rows = []
    for name in SYSTEMS:
        base = read_cif(os.path.join(DATA, name, "eclipsed-AA.cif"))
        for n in (1, 4, 8, 16, 26):
            big = supercell(base, n)
            if big.natoms > 70000:
                # skips nothing in the benchmark set: the largest case,
                # COF-5 26 x 26 (64 896 atoms), must stay included
                continue
            # every repeat is kept, not just the fastest: the table reports a
            # mean and a standard deviation, which a best-of-N cannot give
            runs = [time_once(big, args.outdir) for _ in range(args.repeats)]
            stats = {k: (statistics.mean(r[k] for r in runs),
                         statistics.pstdev(r[k] for r in runs))
                     for k in ("setup", "build", "write", "zip", "total")}
            peak = working_set_gb()
            rows.append(dict(name=name, n=n, natoms=big.natoms, runs=runs,
                             stats=stats, peak=peak))
            print("%-9s %5d %8d %9s %9s %9s %9s %9s %8.3f"
                  % (name, n * n, big.natoms,
                     "%.3f+-%.3f" % stats["setup"],
                     "%.3f+-%.3f" % stats["build"],
                     "%.3f+-%.3f" % stats["write"],
                     "%.3f+-%.3f" % stats["zip"],
                     "%.3f+-%.3f" % stats["total"], peak))

    biggest = max(rows, key=lambda r: r["natoms"])
    print()
    print("largest input tested : %s %dx%d, %d atoms -> %.2f +- %.2f s end to end"
          % (biggest["name"], biggest["n"], biggest["n"], biggest["natoms"],
             biggest["stats"]["total"][0], biggest["stats"]["total"][1]))
    print("peak working set     : %.3f GB (reached at that configuration)" % biggest["peak"])
    print()
    print("Every configuration above is the full pipeline: parse, layer "
          "analysis,\noffset determination, four constructions, four writes.")
    return rows


if __name__ == "__main__":
    main()
