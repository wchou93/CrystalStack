# -*- coding: utf-8 -*-
"""End-to-end smoke test of the Flask layer-stacking app.

Drives the full three-step flow with the Werkzeug test client using the real
COF-1, COF-5, CTF-1 and Pc-PBBA monolayers as inputs, then verifies that the
produced CIF files are well formed and carry the expected atom counts.
"""

from __future__ import annotations

import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from cif_io import read_cif  # noqa: E402

DATA = os.path.join(HERE, "reference")
OUT = os.path.join(HERE, "_smoke_out.txt")

log = []


def say(msg=""):
    log.append(str(msg))


def upload(client, path, modes=("inclined", "serrated", "staggered"),
           offset=None, interlayer=""):
    """Run the whole 3-step flow and return the final response."""
    with open(path, "rb") as fh:
        data = fh.read()
    r1 = client.post(
        "/configure",
        data={"structure_file": (io.BytesIO(data), os.path.basename(path))},
        content_type="multipart/form-data",
        follow_redirects=False,
    )
    assert r1.status_code in (302, 200), "upload failed: %s" % r1.status_code
    # follow to the parameter panel
    r2 = client.get("/configure")
    assert r2.status_code == 200, "panel failed: %s" % r2.status_code
    assert b"parameter" in r2.data.lower() or b"Stacking" in r2.data, "panel body odd"

    form = {"modes": list(modes), "offset_mode": "auto", "interlayer": interlayer}
    if offset is not None:
        form["offset_mode"] = "manual"
        form["offset_fx"] = str(offset[0])
        form["offset_fy"] = str(offset[1])
    return client.post("/process", data=form, follow_redirects=False)


def check(client, name, path, modes, expected_counts):
    """One system: run the flow and validate the generated files."""
    say("=== %s ===" % name)
    r = upload(client, path, modes)
    if r.status_code != 200:
        say("  FAIL  /process returned %s" % r.status_code)
        return False
    html = r.data.decode("utf-8", "ignore")

    ok = True
    # every requested mode should have produced a file row
    for mode in modes:
        if ("%s.cif" % mode) not in html:
            say("  FAIL  %s: no row for %s.cif" % (name, mode))
            ok = False
        else:
            say("  ok    %s: %s.cif listed" % (name, mode))

    # locate the run directory and inspect the files on disk
    m = re.search(r"outputs/(run-[0-9a-zA-Z\-]+)/", html)
    if not m:
        m = re.search(r"(run-[0-9]{8}-[0-9]{6}-[0-9]+)", html)
    if not m:
        say("  FAIL  %s: could not find the run directory in the page" % name)
        return False
    run = m.group(1)
    run_dir = os.path.join(HERE, "outputs", run)

    for mode in modes:
        fp = os.path.join(run_dir, "%s.cif" % mode)
        if not os.path.isfile(fp):
            say("  FAIL  %s: file missing %s" % (name, os.path.basename(fp)))
            ok = False
            continue
        s = read_cif(fp)
        want = expected_counts[mode]
        if s.natoms != want:
            say("  FAIL  %s/%s: %d atoms, expected %d"
                % (name, mode, s.natoms, want))
            ok = False
        else:
            say("  ok    %s/%s: %d atoms" % (name, mode, s.natoms))
        # inclined keeps a 3-vector c with a real in-plane component
        if mode == "inclined":
            cxy = float((s.lattice[2][0] ** 2 + s.lattice[2][1] ** 2) ** 0.5)
            if cxy < 0.5:
                say("  FAIL  %s/inclined: c vector not tilted (%.3f)" % (name, cxy))
                ok = False
            else:
                say("  ok    %s/inclined: c tilt %0.3f A" % (name, cxy))
        else:
            if abs(s.lattice[2][0]) > 1e-6 or abs(s.lattice[2][1]) > 1e-6:
                say("  FAIL  %s/%s: c vector should be vertical" % (name, mode))
                ok = False

    # the ZIP bundle must exist and hold one entry per mode
    zp = os.path.join(run_dir, "layer_stacking.zip")
    if not os.path.isfile(zp):
        say("  FAIL  %s: ZIP missing" % name)
        ok = False
    else:
        import zipfile
        with zipfile.ZipFile(zp) as zf:
            names = zf.namelist()
        if len(names) != len(modes):
            say("  FAIL  %s: ZIP has %d files, expected %d"
                % (name, len(names), len(modes)))
            ok = False
        else:
            say("  ok    %s: ZIP holds %s" % (name, ", ".join(sorted(names))))
    return ok


def main():
    from app import app

    app.config["TESTING"] = True
    app.config["WTF_CSRF_ENABLED"] = False

    systems = [
        ("COF-1", "COF-1", 42),
        ("COF-5", "COF-5", 96),
        ("CTF-1", "CTF-1", 42),
        ("Pc-PBBA", "Pc-PBBA", 82),
    ]

    all_ok = True
    for label, folder, n in systems:
        path = os.path.join(DATA, folder, "eclipsed-AA.cif")
        if not os.path.isfile(path):
            say("SKIP %s (no input)" % label)
            continue
        expected = {
            "eclipsed": n,
            "inclined": n,
            "serrated": 2 * n,
            "staggered": 2 * n,
        }
        with app.test_client() as c:
            all_ok &= check(c, label, path, ["inclined", "serrated", "staggered"],
                            expected)

    # --- a second pass: all four modes, with a manual offset -------------
    say("")
    say("=== COF-1, four modes, manual offset ===")
    path = os.path.join(DATA, "COF-1", "eclipsed-AA.cif")
    with app.test_client() as c:
        all_ok &= check(c, "COF-1-manual", path,
                        ["eclipsed", "inclined", "serrated", "staggered"],
                        {"eclipsed": 42, "inclined": 42,
                         "serrated": 84, "staggered": 84})
        # now a truly manual offset for the slipped modes only
        r = upload(c, path, ["serrated"], offset=(0.132392, 0.065956))
        if r.status_code != 200:
            say("  FAIL  manual offset run returned %s" % r.status_code)
            all_ok = False
        else:
            html = r.data.decode("utf-8", "ignore")
            # the summary table should carry the manual-source label
            if "\u624b\u52a8" in html or ">manual<" in html:
                say("  ok    manual offset reported in the summary table")
            else:
                say("  FAIL  manual offset not reported")
                all_ok = False

    # --- the language switch --------------------------------------------
    say("")
    say("=== language switch ===")
    with app.test_client() as c:
        c.get("/")
        c.get("/set_language/en")
        r = c.get("/")
        body = r.data.decode("utf-8", "ignore")
        if "Upload a monolayer" in body:
            say("  ok    English page renders")
        else:
            say("  FAIL  English page missing expected text")
            all_ok = False
        c.get("/set_language/zh")
        r = c.get("/")
        body = r.data.decode("utf-8", "ignore")
        if "Upload a monolayer" in body:
            say("  ok    zh session falls back to English (English-only build)")
        else:
            say("  FAIL  zh fallback page missing expected text")
            all_ok = False

    # --- batch upload: two monolayers at once ----------------------------
    say("")
    say("=== batch upload (two monolayers) ===")
    with app.test_client() as c:
        data = {"structure_file": [
            (io.BytesIO(open(os.path.join(DATA, "COF-1", "eclipsed-AA.cif"), "rb").read()),
             "COF-1.cif"),
            (io.BytesIO(open(os.path.join(DATA, "Pc-PBBA", "eclipsed-AA.cif"), "rb").read()),
             "Pc-PBBA.cif"),
        ]}
        r = c.post("/configure", data=data, content_type="multipart/form-data",
                   follow_redirects=False)
        if r.status_code != 302:
            say("  FAIL  batch upload returned %s" % r.status_code)
            all_ok = False
        else:
            r = c.post("/process", data={"modes": ["inclined", "serrated"],
                                         "offset_mode": "auto"},
                       follow_redirects=False)
            html = r.data.decode("utf-8", "ignore")
            ok = True
            for stem in ("COF-1", "Pc-PBBA"):
                for mode in ("inclined", "serrated"):
                    if "%s/%s.cif" % (stem, mode) not in html:
                        say("  FAIL  batch: %s/%s.cif not listed" % (stem, mode))
                        ok = False
            m = re.search(r"(run-[0-9]{8}-[0-9]{6}-[0-9]+)", html)
            if not m:
                say("  FAIL  batch: run directory not found")
                ok = False
            else:
                zp = os.path.join(HERE, "outputs", m.group(1), "layer_stacking.zip")
                import zipfile as _zf
                with _zf.ZipFile(zp) as zf:
                    names = zf.namelist()
                if len(names) != 4:
                    say("  FAIL  batch: ZIP holds %d files, expected 4" % len(names))
                    ok = False
                elif "COF-1/inclined.cif" not in names:
                    say("  FAIL  batch: ZIP misses per-file folders")
                    ok = False
                else:
                    say("  ok    batch: 4 structures in per-file folders")
            all_ok &= ok

    # --- monolayer extraction from a bilayer ------------------------------
    say("")
    say("=== monolayer extraction ===")
    with app.test_client() as c:
        r = c.post("/configure", data={"structure_file": (
            io.BytesIO(open(os.path.join(DATA, "COF-1", "serrated-AA.cif"), "rb").read()),
            "serrated.cif")}, content_type="multipart/form-data",
            follow_redirects=False)
        panel = c.get("/configure")
        if b"extract_monolayer" not in panel.data:
            say("  FAIL  extraction checkbox not offered for a multilayer input")
            all_ok = False
        r = c.post("/process", data={"modes": ["inclined"], "offset_mode": "auto",
                                     "extract_monolayer": "on"},
                   follow_redirects=False)
        html = r.data.decode("utf-8", "ignore")
        m = re.search(r"(run-[0-9]{8}-[0-9]{6}-[0-9]+)", html)
        if m and "monolayer.cif" in html:
            from cif_io import read_cif as _read
            mono = _read(os.path.join(HERE, "outputs", m.group(1), "monolayer.cif"))
            if mono.natoms == 42:
                say("  ok    monolayer.cif holds 42 atoms (c = %.3f A)"
                    % mono.abc[2])
            else:
                say("  FAIL  monolayer.cif has %d atoms" % mono.natoms)
                all_ok = False
        else:
            say("  FAIL  monolayer.cif not produced")
            all_ok = False

    # --- rotated mode: unvalidated operations must warn --------------------
    say("")
    say("=== rotated-mode validation warning ===")
    with app.test_client() as c:
        c.post("/configure", data={"structure_file": (
            io.BytesIO(open(os.path.join(DATA, "CTF-1", "eclipsed-AA.cif"), "rb").read()),
            "CTF-1.cif")}, content_type="multipart/form-data", follow_redirects=False)
        r = c.post("/process", data={"modes": ["rotated"], "offset_mode": "auto"},
                   follow_redirects=False)
        html = r.data.decode("utf-8", "ignore")
        if "not a symmetry operation" in html and "not validated" in html:
            say("  ok    CTF-1 rot120 warns and is marked unvalidated")
        else:
            say("  FAIL  unvalidated rotated operation passed silently")
            all_ok = False

    say("")
    say("RESULT: %s" % ("all checks passed" if all_ok else "FAILURES PRESENT"))
    with io.open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(log))
    print("written", OUT)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
