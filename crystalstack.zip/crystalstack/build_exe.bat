@echo off
rem =====================================================================
rem  CrystalStack -- build the single-file Windows exe
rem
rem  Plain ASCII on purpose: cmd.exe parses a .bat file in the console's
rem  ANSI codepage, so non-ASCII text gets mis-decoded. Keep CRLF endings.
rem
rem  All the real work (venv, dependencies, PyInstaller arguments) lives in
rem  build_exe.py -- this file only finds a Python, calls it, and pauses.
rem
rem  Pass --clean to keep build_env\ and build\ for faster rebuilds:
rem      build_exe.bat --clean
rem =====================================================================
title CrystalStack - build exe
cd /d "%~dp0"

echo ============================================
echo   CrystalStack - build single-file exe
echo ============================================
echo.

rem ---- 1. interpreter ------------------------------------------------
rem Do not trust "where python": on Windows 10/11 that also finds the
rem Microsoft Store stub, which exists but cannot create a virtualenv.
set "PY="
for %%P in (py python python3) do (
    if not defined PY (
        %%P -c "import sys; raise SystemExit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
        if not errorlevel 1 set "PY=%%P"
    )
)
if not defined PY (
    echo [error] Python 3.10 or newer not found on PATH.
    echo         Install it from https://www.python.org/downloads/ and
    echo         tick "Add python.exe to PATH" during setup.
    echo.
    pause
    exit /b 1
)

rem ---- 2. build ------------------------------------------------------
if not exist "build_exe.py" (
    echo [error] build_exe.py not found next to this script.
    pause
    exit /b 1
)

echo [1/2] Building ... this takes a few minutes on the first run.
echo       The exe is written to the dist\ folder.
echo.
%PY% "build_exe.py" %*
set "RC=%errorlevel%"

rem ---- 3. result -----------------------------------------------------
echo.
if not "dist\CrystalStack.exe" exist (
    echo [2/2] [error] Build did not produce dist\CrystalStack.exe.
    echo        Scroll up for the failing command.
    pause
    exit /b 1
)
if not "%RC%"=="0" (
    echo [2/2] [error] build_exe.py exited with code %RC%.
    pause
    exit /b %RC%
)

for %%F in ("dist\CrystalStack.exe") do echo [2/2] Done: %%~fF  (%%~zF bytes)
echo.
echo Copy CrystalStack.exe to any Windows machine and double-click it.
echo No Python installation is required on that machine.
echo.
pause
exit /b 0