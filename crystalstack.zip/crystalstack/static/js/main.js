// 2D Layer Stacking - interface behaviour
// (1) client-side file size guard + file name preview
// (2) show/hide the manual in-plane offset inputs
// (3) show/hide the symmetry-operation selector (rotated mode only)

document.addEventListener('DOMContentLoaded', function () {

    // ---- (1) file upload box -------------------------------------------
    const fileInput = document.getElementById('structure_file');
    const fileBoxName = document.getElementById('fileBoxName');

    if (fileInput && fileBoxName) {
        fileInput.addEventListener('change', function () {
            const empty = fileBoxName.dataset.empty || '';
            const file = this.files[0];
            if (!file) {
                fileBoxName.textContent = empty;
                return;
            }
            if (file.size / 1024 / 1024 > 16) {
                alert('File size cannot exceed 16 MB!');
                this.value = '';
                fileBoxName.textContent = empty;
                return;
            }
            fileBoxName.textContent = file.name;
        });
    }

    // ---- (2) offset mode ------------------------------------------------
    const modeSelect = document.getElementById('offset_mode');
    const manualOptions = document.getElementById('manual_offset_options');

    if (modeSelect && manualOptions) {
        const sync = function () {
            manualOptions.style.display = (modeSelect.value === 'manual') ? 'block' : 'none';
        };
        modeSelect.addEventListener('change', sync);
        sync();
    }

    // ---- (3) symmetry operation (rotated mode) --------------------------
    // The selector is only meaningful when the "rotated" mode is ticked, so
    // it is hidden (rather than disabled) until that box is checked.  Pages
    // that do not offer the mode at all have no #symmetry_field and are
    // left completely untouched.
    const symField = document.getElementById('symmetry_field');
    const rotatedBox = document.getElementById('mode_rotated');

    if (symField && rotatedBox) {
        const syncSym = function () {
            symField.style.display = rotatedBox.checked ? 'block' : 'none';
        };
        rotatedBox.addEventListener('change', syncSym);
        syncSym();
    }
});
