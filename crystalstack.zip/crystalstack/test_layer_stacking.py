# -*- coding: utf-8 -*-
"""Self-contained test suite for the 2D layer-stacking engine.

Runs without pytest::

    python test_layer_stacking.py

Every check is reported as ``ok`` / ``FAIL`` and the exit status is non-zero
if any check fails.

The offset checks in section 3b/4b are **gold-standard**: the expected values
are the offsets recovered from the reference structures themselves by a grid
scan of the residual (slide layer 2 back and measure how well it lands on
layer 1).  The residuals of that recovery are 0.01-0.06 A, so the expected
values are good to better than 0.1 A and they are independent of the engine's
own logic.

An earlier version of this file asserted the engine's *own* output as expected
(``COF-5 AB magnitude ~ (1/3, 1/3)``, with a 35 % + 1 A tolerance) which is why
two real bugs went unnoticed: the engine offset COF-5 by 2.1x and both COF-5
and Pc-PBBA by the wrong pore vector.  Tolerances below are tight on purpose;
a failure here means the engine regressed, not the test.
"""

from __future__ import annotations

import io
import math
import sys
import os

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cif_io import read_cif, write_cif, Structure  # noqa: E402
from layer_stacking import (  # noqa: E402
    LayerStackingEngine,
    REFERENCE_AA_FRACTIONAL,
    REFERENCE_AA_OFFSETS,
    REFERENCE_CELLS,
    AA_FRACTIONAL_HEXAGONAL,
    AA_FRACTIONAL_SQUARE,
)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
REFERENCE = os.path.join(HERE, "reference")

#: True offsets recovered from the reference structures by grid-scanning the
#: interlayer residual (see the module docstring).  Fractional (a, b).
TRUE_OFFSETS = {
    ("COF-1", "serrated"): (0.13463, 0.06790),
    ("COF-1", "staggered"): (-0.33216, 0.33451),
    ("COF-5", "serrated"): (0.05556, 0.00117),
    ("COF-5", "staggered"): (-0.32716, 0.33451),
    ("CTF-1", "serrated"): (0.13463, 0.06790),
    ("CTF-1", "staggered"): (-0.31481, 0.32716),
    ("Pc-PBBA", "serrated"): (0.06056, 0.03586),
    ("Pc-PBBA", "staggered"): (-0.50000, -0.50000),
}

#: A reference structure is a separate DFT relaxation, so its cell and its
#: atomic positions differ slightly from the input monolayer.  CTF-1 is the
#: loosest case at 0.32 A (4 % of the offset); everything else is under 0.18 A.
OFFSET_TOL = 0.35

_failures = []
_checks = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global _checks
    _checks += 1
    if condition:
        print("  ok    %s" % name)
    else:
        print("  FAIL  %s   %s" % (name, detail))
        _failures.append(name)


def close(name: str, got: float, want: float, tol: float) -> None:
    check(name, abs(got - want) <= tol,
          "got %.4f want %.4f (tol %.4f)" % (got, want, tol))


def offset_error(got_frac: np.ndarray, true_frac, a2d: np.ndarray) -> float:
    """Smallest in-plane separation between two offsets, modulo the lattice
    translations and the inversion that describe the same periodic geometry."""
    got = np.asarray(got_frac, dtype=float)
    true = np.asarray(true_frac, dtype=float)
    best = np.inf
    for sx in (-2, -1, 0, 1, 2):
        for sy in (-2, -1, 0, 1, 2):
            for sign in (1.0, -1.0):
                cand = sign * true + np.array([sx, sy], dtype=float)
                best = min(best, float(np.linalg.norm((got - cand) @ a2d)))
    return best


def max_layer_deviation(a: Structure, b: Structure):
    """Largest same-species in-plane mismatch between two structures."""
    if len(a.frac_coords) != len(b.frac_coords):
        return None
    fa = a.frac_coords[:, :2]
    fb = b.frac_coords[:, :2]
    vb = b.lattice[:2, :2]
    sa = a.species_per_atom
    sb = b.species_per_atom
    worst = 0.0
    for i in range(len(fa)):
        sel = sb == sa[i]
        if not sel.any():
            return None
        cand = fb[sel]
        best = np.inf
        for ix in (-1, 0, 1):
            for iy in (-1, 0, 1):
                d = (cand + np.array([ix, iy]) - fa[i]) @ vb
                best = min(best, float(np.linalg.norm(d, axis=1).min()))
        worst = max(worst, best)
    return worst


def load(system: str, name: str) -> Structure:
    return read_cif(os.path.join(REFERENCE, system, name))


# --------------------------------------------------------------------- #
# 1. CIF reader
# --------------------------------------------------------------------- #
print("CIF reader")
src = load("COF-1", "eclipsed-AA.cif")
check("COF-1 atom count", src.natoms == 42, "got %d" % src.natoms)
check("COF-1 formula", src.formula.replace(" ", "") == "B6O6C18H12",
      "got %r" % src.formula)
close("COF-1 a length", src.abc[0], 14.96397, 1e-4)
close("COF-1 c length", src.abc[2], 3.74507, 1e-4)

ser = load("COF-1", "serrated-AA.cif")
check("serrated atom count", ser.natoms == 84, "got %d" % ser.natoms)
check("serrated counts doubled", ser.counts == [12, 12, 36, 24],
      "got %s" % ser.counts)

# the reader must ignore a trailing velocity block
tmp = os.path.join(HERE, "_tmp_roundtrip.cif")
write_cif(src, tmp)
back = read_cif(tmp)
check("round-trip atom count", back.natoms == src.natoms)
check("round-trip lattice", bool(np.allclose(back.lattice, src.lattice)))
os.remove(tmp)

# --------------------------------------------------------------------- #
# 2. layer analysis
# --------------------------------------------------------------------- #
print("layer analysis")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    check("%s is a monolayer" % system, eng.is_monolayer)
    check("%s has one layer" % system, eng.n_layers == 1, "got %d" % eng.n_layers)

check("COF-1 lattice is hexagonal",
      LayerStackingEngine(load("COF-1", "eclipsed-AA.cif")).lattice_type == "hexagonal")
check("Pc-PBBA lattice is square",
      LayerStackingEngine(load("Pc-PBBA", "eclipsed-AA.cif")).lattice_type == "square")
check("COF-5 lattice is hexagonal",
      LayerStackingEngine(load("COF-5", "eclipsed-AA.cif")).lattice_type == "hexagonal")

# --------------------------------------------------------------------- #
# 3a. AA' offset -- recognition of the tabulated systems
# --------------------------------------------------------------------- #
print("AA' offset: recognised systems")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    a2d = eng._a2d
    got, _quality, source = eng.aa_offset()
    err = offset_error(got, REFERENCE_AA_FRACTIONAL[system], a2d)
    check("%s AA' matches its measured value (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL, "error %.4f A, source=%s" % (err, source))
    check("%s AA' is recognised by cell match" % system,
          source == "reference:" + system, "got source=%r" % source)
    check("%s AA' is not flagged ambiguous" % system, not eng.aa_is_ambiguous())

# the recognition must be driven by the cell, not by the file name
fake = load("COF-1", "eclipsed-AA.cif")
check("COF-1 cell fingerprint is tabulated",
      abs(fake.abc[0] - REFERENCE_CELLS["COF-1"][0]) < 0.05)

# --------------------------------------------------------------------- #
# 3b. AA' offset -- GOLD STANDARD against the reference structures
# --------------------------------------------------------------------- #
print("AA' offset: gold standard (engine vs reference structures)")
n_ok = 0
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    got, _quality, source = eng.aa_offset()
    true = TRUE_OFFSETS[(system, "serrated")]
    err = offset_error(got, true, eng._a2d)
    n_ok += bool(err < OFFSET_TOL)
    check("%s serrated offset matches the reference (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL,
          "got (%+.5f,%+.5f) true (%+.5f,%+.5f) error %.4f A [%s]" % (
              got[0], got[1], true[0], true[1], err, source))
check("all four serrated offsets pass", n_ok == 4, "%d/4" % n_ok)

# --------------------------------------------------------------------- #
# 3c. AA' offset -- the hexagonal / square rules themselves
# --------------------------------------------------------------------- #
print("AA' offset: fractional rules")
# The rule must reproduce COF-1 and CTF-1 (which are NOT the same cell size,
# so this tests the fractional -- not the angstrom -- constancy).
for system in ("COF-1", "CTF-1"):
    s = load(system, "eclipsed-AA.cif")
    rule = np.array(AA_FRACTIONAL_HEXAGONAL) @ s.lattice[:2, :2]
    true = np.array(TRUE_OFFSETS[(system, "serrated")]) @ s.lattice[:2, :2]
    close("%s hexagonal rule reproduces the slip (angstroms)" % system,
          float(np.linalg.norm(rule)), float(np.linalg.norm(true)), 0.06)
# The *physical* invariant: for a hexagonal cell with |a| = |b| = c and
# gamma = 120, (2/15, 1/15) @ a2d has the exact magnitude
#     |f|^2 = (2/15)^2 - (2/15)(1/15) + (1/15)^2 = 3/225 = 1/75
#     |f|   = sqrt(3)/15 = 0.1154701...  |a|
# (0.1146, which older comments quote, is the measured COF-1 offset over its
#  cell -- 1.7157 / 14.9640 -- and not a rounding of this constant)
#
# The tolerance is 1e-6, not machine epsilon: the CIF carries 8 decimal
# places, and |b| is stored as 12.95917560 rather than 12.95917561..., which
# alone shifts the ratio by ~5e-8.  That is input rounding, not an error in
# the rule.
_s_hex = load("COF-1", "eclipsed-AA.cif")
_hex_shift = float(np.linalg.norm(np.array(AA_FRACTIONAL_HEXAGONAL) @ _s_hex.lattice[:2, :2]))
_hex_a = float(np.linalg.norm(_s_hex.lattice[0, :2]))
close("hexagonal rule magnitude is exactly sqrt(3)/15 |a| = 0.115470|a|",
      _hex_shift / _hex_a, math.sqrt(3.0) / 15.0, 1e-6)
print("        (|a| = %.5f A -> |delta| = %.4f A)" % (_hex_a, _hex_shift))
close("hexagonal rule is exactly 30 deg from a",
      math.degrees(math.atan2((np.array(AA_FRACTIONAL_HEXAGONAL) @
                               np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]]))[1],
                              (np.array(AA_FRACTIONAL_HEXAGONAL) @
                               np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]]))[0])),
      30.0, 0.01)

# A new framework must NOT be silently given a value that may be 2x wrong:
# scaling COF-5's cell breaks the recognition and must raise the flag.
newcell = load("COF-5", "eclipsed-AA.cif")
newcell.lattice = newcell.lattice * 1.10
eng = LayerStackingEngine(newcell)
_off, _q, source = eng.aa_offset()
check("unrecognised COF-5-like cell is flagged", source == "rule (unverified)",
      "got %r" % source)
check("unrecognised COF-5-like cell reports ambiguity", eng.aa_is_ambiguous())

newcell2 = load("COF-1", "eclipsed-AA.cif")
newcell2.lattice = newcell2.lattice * 1.10
eng2 = LayerStackingEngine(newcell2)
_off2, _q2, source2 = eng2.aa_offset()
check("unrecognised COF-1-like cell is not flagged", source2 == "default",
      "got %r" % source2)
check("unrecognised COF-1-like cell is not ambiguous", not eng2.aa_is_ambiguous())

# --------------------------------------------------------------------- #
# 4a. AB offset -- selection by lattice type
# --------------------------------------------------------------------- #
print("AB offset: lattice type")
from stacking_rules import PORE_FRACTIONAL_HEXAGONAL, PORE_FRACTIONAL_SQUARE  # noqa: E402
for system, want in (("COF-1", PORE_FRACTIONAL_HEXAGONAL),
                     ("COF-5", PORE_FRACTIONAL_HEXAGONAL),
                     ("CTF-1", PORE_FRACTIONAL_HEXAGONAL),
                     ("Pc-PBBA", PORE_FRACTIONAL_SQUARE)):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    ab, quality, source = eng.ab_offset()
    err = offset_error(ab, want, eng._a2d)
    check("%s AB is the %s pore" % (system, "hexagonal" if want == PORE_FRACTIONAL_HEXAGONAL
                                    else "square"),
          err < 0.05, "error %.4f A, source=%s" % (err, source))

# --------------------------------------------------------------------- #
# 4b. AB offset -- GOLD STANDARD against the reference structures
# --------------------------------------------------------------------- #
print("AB offset: gold standard (engine vs reference structures)")
n_ok = 0
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    got, _quality, source = eng.ab_offset()
    true = TRUE_OFFSETS[(system, "staggered")]
    err = offset_error(got, true, eng._a2d)
    n_ok += bool(err < OFFSET_TOL)
    check("%s staggered offset matches the reference (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL,
          "got (%+.5f,%+.5f) true (%+.5f,%+.5f) error %.4f A [%s]" % (
              got[0], got[1], true[0], true[1], err, source))
check("all four staggered offsets pass", n_ok == 4, "%d/4" % n_ok)

# The staggered offset must differ from the serrated one -- if the engine ever
# returns the same vector for both, one of them is wrong.
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    aa, _, _ = eng.aa_offset()
    ab, _, _ = eng.ab_offset()
    check("%s serrated and staggered offsets differ" % system,
          offset_error(aa, ab, eng._a2d) > 0.5)

# --------------------------------------------------------------------- #
# 5. construction: atom counts and geometry
# --------------------------------------------------------------------- #
print("construction")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    n = s.natoms
    inc = eng.build("inclined")
    check("%s inclined conserves atoms" % system, inc.natoms_output == n,
          "%d -> %d" % (n, inc.natoms_output))
    ser_ = eng.build("serrated")
    check("%s serrated doubles atoms" % system, ser_.natoms_output == 2 * n,
          "%d -> %d" % (n, ser_.natoms_output))
    stg = eng.build("staggered")
    check("%s staggered doubles atoms" % system, stg.natoms_output == 2 * n,
          "%d -> %d" % (n, stg.natoms_output))
    check("%s inclined c-vector is tilted" % system,
          abs(inc.structure.lattice[2][2] - s.abc[2]) < 1e-6)
    check("%s serrated c is doubled" % system,
          abs(ser_.c_length - 2 * s.abc[2]) < 1e-6,
          "%.4f vs %.4f" % (ser_.c_length, 2 * s.abc[2]))
    # a doubled build must actually contain two separated layers
    groups = stg.structure.layer_groups(None)
    check("%s staggered has two layers" % system, len(groups) == 2,
          "%d groups" % len(groups))
    if len(groups) == 2:
        check("%s staggered layers are equal in size" % system,
              len(groups[0]) == len(groups[1]), "%d vs %d" % (len(groups[0]), len(groups[1])))

# the inclined mode must not move the atoms *in fractional coordinates*: only
# the c row changes, so the Cartesians shift by the shear z * (dx, dy, 0)
for system in ("COF-1", "CTF-1"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    inc = eng.build("inclined")
    check("%s inclined carries the fractional coordinates over unchanged" % system,
          bool(np.allclose(inc.structure.frac_coords, s.frac_coords)))
    check("%s inclined changes only the c row of the lattice" % system,
          bool(np.allclose(inc.structure.lattice[:2], s.lattice[:2])))

# --------------------------------------------------------------------- #
# 6. offline reproduction of the reference structures
# --------------------------------------------------------------------- #
print("reference reproduction (serrated, measured offset)")
# Feeding the *measured* offset must reproduce the reference structure itself.
# This validates the construction, independently of the offset choice.
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    off = list(REFERENCE_AA_FRACTIONAL[system])
    ref = load(system, "serrated-AA.cif")
    res = eng.build("serrated", offset=off)
    check("%s serrated atom count matches reference" % system,
          res.structure.natoms == ref.natoms,
          "%d vs %d" % (res.structure.natoms, ref.natoms))
    # in-plane displacement between the two layers of the generated structure
    # must equal the requested offset
    g = res.structure.layer_groups(None)
    if len(g) == 2:
        a2d = res.structure.lattice[:2, :2]
        lo = res.structure.frac_coords[g[0]][:, :2]
        hi = res.structure.frac_coords[g[1]][:, :2]
        # match per species to get the rigid shift
        sp = res.structure.species_per_atom
        d = []
        for sym in set(map(str, sp)):
            ca = lo[sp[g[0]] == sym]
            cb = hi[sp[g[1]] == sym]
            if len(ca) == len(cb) and len(ca):
                dv = cb - ca
                dv -= np.round(dv)
                d.append(dv.mean(axis=0))
        if d:
            shift = np.mean(d, axis=0)
            err = offset_error(shift, off, a2d)
            check("%s serrated layers are separated by the requested offset" % system,
                  err < 0.05, "error %.4f A" % err)

# --------------------------------------------------------------------- #
# 7. manual override plumbing
# --------------------------------------------------------------------- #
print("manual override")
eng = LayerStackingEngine(load("COF-1", "eclipsed-AA.cif"))
r1 = eng.build("serrated", offset=[0.10, 0.05])
r2 = eng.build("serrated", offset=[0.20, 0.10])
check("manual fractional offset is respected",
      not np.allclose(r1.offset_frac, r2.offset_frac))
check("manual offset reports source", r1.offset_source == "manual",
      "got %r" % r1.offset_source)

r3 = eng.build("inclined", offset=[2.0, 1.0])  # angstroms
check("cartesian offset is interpreted in angstroms",
      abs(r3.offset_magnitude - math.hypot(2.0, 1.0)) < 1e-6,
      "got %.4f" % r3.offset_magnitude)

# a manual offset must reach the output structure
eng_c5 = LayerStackingEngine(load("COF-5", "eclipsed-AA.cif"))
manual = list(REFERENCE_AA_FRACTIONAL["COF-5"])
res_manual = eng_c5.build("serrated", offset=manual)
g = res_manual.structure.layer_groups(None)
if len(g) == 2:
    sp = res_manual.structure.species_per_atom
    lo = res_manual.structure.frac_coords[g[0]][:, :2]
    hi = res_manual.structure.frac_coords[g[1]][:, :2]
    d = []
    for sym in set(map(str, sp)):
        ca = lo[sp[g[0]] == sym]
        cb = hi[sp[g[1]] == sym]
        if len(ca) == len(cb) and len(ca):
            dv = cb - ca
            dv -= np.round(dv)
            d.append(dv.mean(axis=0))
    if d:
        shift = np.mean(d, axis=0)
        check("COF-5 manual override lands on the requested offset",
              offset_error(shift, manual, res_manual.structure.lattice[:2, :2]) < 0.05)

try:
    eng.build("nonsense")
    check("unknown mode is rejected", False, "no exception raised")
except ValueError:
    check("unknown mode is rejected", True)

# --------------------------------------------------------------------- #
# 8. rotated mode -- symmetry validation (defect report D-1)
# --------------------------------------------------------------------- #
print("rotated mode: symmetry validation")
from stacking_rules import SYMMETRY_OPS, CANDIDATE_AXIS_SHIFTS  # noqa: E402

# the two new preset angles exist and act as honest 60 / 300 degree rotations
_m60 = dict((k, m) for k, _l, m in SYMMETRY_OPS)["rot60"]
_m300 = dict((k, m) for k, _l, m in SYMMETRY_OPS)["rot300"]
_hex = np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]])   # a, b as columns frame
_a_img = _m60 @ np.array([1.0, 0.0])
close("rot60 maps a onto a+b", float(np.linalg.norm(_a_img @ _hex - (np.array([1, 0]) + np.array([0, 1])) @ _hex)), 0.0, 1e-9)
_a_img300 = _m300 @ np.array([1.0, 0.0])
close("rot300 maps a onto -b", float(np.linalg.norm(_a_img300 @ _hex - (np.array([0, -1])) @ _hex)), 0.0, 1e-9)

# COF-5: the transpose is an exact symmetry operation about the origin.
eng = LayerStackingEngine(load("COF-5", "eclipsed-AA.cif"))
res = eng.build("rotated", symmetry="transpose")
check("COF-5 transpose validates about the origin",
      res.symmetry_residual is not None and res.symmetry_residual < 1e-3,
      "residual %s" % res.symmetry_residual)
check("COF-5 transpose source is validated symmetry",
      res.offset_source == "symmetry", "got %r" % res.offset_source)
check("COF-5 transpose raises no warning",
      not any(n.startswith("WARNING") for n in res.notes))
check("COF-5 rotated result carries axis/residual in its summary",
      res.summary().get("symmetry_residual") is not None)

# COF-1: the transpose fails about the origin but is exact about an axis at
# (1/6, 5/6)-type positions -- the axis search must find it (defect D-1).
eng_c1 = LayerStackingEngine(load("COF-1", "eclipsed-AA.cif"))
r_origin = eng_c1.symmetry_residual("transpose", (0.0, 0.0))
check("COF-1 transpose is NOT a symmetry operation about the origin",
      r_origin > 1.0, "residual %.4f" % r_origin)
best_r, best_p = eng_c1.best_symmetry_axis("transpose")
check("COF-1 transpose validates about a searched axis",
      best_r < eng_c1.symmetry_tol, "residual %.4f at %s" % (best_r, best_p))
res_c1 = eng_c1.build("rotated", symmetry="transpose")
check("COF-1 rotated build uses the searched axis",
      abs(res_c1.symmetry_axis[0] - best_p[0]) < 1e-6
      and abs(res_c1.symmetry_axis[1] - best_p[1]) < 1e-6,
      "axis %s" % (res_c1.symmetry_axis,))
check("COF-1 rotated transpose validates end to end",
      res_c1.offset_source == "symmetry"
      and res_c1.symmetry_residual < eng_c1.symmetry_tol)

# CTF-1: the buckled relaxed layer has no exact operation; the engine must
# say so loudly instead of stacking silently.
eng_ctf = LayerStackingEngine(load("CTF-1", "eclipsed-AA.cif"))
res_ctf = eng_ctf.build("rotated", symmetry="rot120")
check("CTF-1 rot120 is flagged unvalidated",
      res_ctf.offset_source == "symmetry (unvalidated)",
      "got %r" % res_ctf.offset_source)
check("CTF-1 rot120 carries a WARNING note",
      any(n.startswith("WARNING") and "not a symmetry operation" in n
          for n in res_ctf.notes))
check("CTF-1 rot120 residual exceeds the tolerance",
      res_ctf.symmetry_residual > eng_ctf.symmetry_tol,
      "residual %s" % res_ctf.symmetry_residual)

# --------------------------------------------------------------------- #
# 9. staggered node-on-node diagnostic (defect report D-1, root cause 2)
# --------------------------------------------------------------------- #
print("staggered node-on-node detection")

def make_supercell(s: Structure, na: int, nb: int) -> Structure:
    """na x nb in-plane supercell, keeping the species-block layout."""
    lat = s.lattice.copy()
    lat[0] *= na
    lat[1] *= nb
    syms, fracs = [], []
    for ia in range(na):
        for ib in range(nb):
            for k in range(s.natoms):
                syms.append(s.species_per_atom[k])
                f = s.frac_coords[k].copy()
                fracs.append([(f[0] + ia) / na, (f[1] + ib) / nb, f[2]])
    return Structure.from_blocks(lattice=lat, symbols=syms,
                                 frac_coords=np.array(fracs),
                                 title=s.title + " supercell")

base_pbba = load("Pc-PBBA", "eclipsed-AA.cif")
eng_ok = LayerStackingEngine(base_pbba)
res_ok = eng_ok.build("staggered")
check("primitive Pc-PBBA staggered raises no warning",
      not any(n.startswith("WARNING") for n in res_ok.notes))

supercell = make_supercell(base_pbba, 2, 2)
eng_sup = LayerStackingEngine(supercell)
check("2x2 Pc-PBBA supercell is still typed square",
      eng_sup.lattice_type == "square", "got %r" % eng_sup.lattice_type)
res_sup = eng_sup.build("staggered")
check("non-primitive cell staggered is diagnosed, never silent",
      any(n.startswith("WARNING") and "maps atoms of layer 2" in n
          for n in res_sup.notes),
      "notes: %s" % res_sup.notes[:1])
check("non-primitive cell staggered is detected as node-on-node",
      res_sup.quality < 0.01, "quality %.4f" % res_sup.quality)
check("the warning points the user at the manual offset",
      any("in-plane offset" in n for n in res_sup.notes if n.startswith("WARNING")))

res_node = eng_sup.build("staggered", offset=[0.5, 0.5])
check("manual (1/2,1/2) on a non-primitive cell triggers node-on-node",
      any(n.startswith("WARNING") and "maps atoms of layer 2" in n
          for n in res_node.notes),
      "notes: %s" % res_node.notes[:1])
check("node-on-node quality is an exact coincidence",
      res_node.quality < 1e-6, "quality %.6f" % res_node.quality)

# --------------------------------------------------------------------- #
# 10. monolayer extraction
# --------------------------------------------------------------------- #
print("monolayer extraction")
from layer_stacking import extract_monolayer  # noqa: E402

mono_in = load("COF-1", "serrated-AA.cif")          # bilayer, c = 6.80 A
check("serrated reference holds two layers", mono_in.n_z_layers == 2)
mono = extract_monolayer(mono_in, 0)
check("extracted layer has the monolayer atom count", mono.natoms == 42,
      "got %d" % mono.natoms)
# the reference file lists O first, the monolayer B first; compare the
# species-count multiset rather than the storage order
check("extracted layer keeps the formula",
      sorted(mono.formula.split()) == sorted("B6 O6 C18 H12".split()),
      "got %r" % mono.formula)
close("extracted c is reset to one layer", mono.abc[2],
      mono_in.abc[2] / 2.0, 1e-6)
second = extract_monolayer(mono_in, 1)
check("second layer extracts too", second.natoms == 42)
check("layer_index out of range is rejected", False, "no exception") if False else None
try:
    extract_monolayer(mono_in, 5)
    check("layer_index out of range is rejected", False, "no exception raised")
except ValueError:
    check("layer_index out of range is rejected", True)
solo = load("COF-1", "eclipsed-AA.cif")
check("a monolayer input extracts to itself",
      extract_monolayer(solo, 0).natoms == solo.natoms)

# --------------------------------------------------------------------- #
# 11. non-layered input rejection and CIF symmetry transparency
# --------------------------------------------------------------------- #
print("input validation and CIF transparency")

chain_cif = os.path.join(HERE, "_tmp_chain.cif")
with io.open(chain_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_chain
_cell_length_a 20.0
_cell_length_b 20.0
_cell_length_c 4.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.50 0.50
C2 C 0.30 0.50 0.50
C3 C 0.50 0.50 0.50
C4 C 0.70 0.50 0.50
""")
try:
    LayerStackingEngine(read_cif(chain_cif))
    check("1D chain is rejected", False, "no exception raised")
except ValueError as exc:
    check("1D chain is rejected", "2D layered material" in str(exc),
          "got %r" % str(exc)[:80])
os.remove(chain_cif)

# symmetry transparency: a declared group without operations must be
# reported, not silently read as its asymmetric unit
bad_cif = os.path.join(HERE, "_tmp_nosym.cif")
with io.open(bad_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_nosym
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
_symmetry_space_group_name_H-M 'P 6/m m m'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
try:
    read_cif(bad_cif)
    check("declared group without operations is rejected", False,
          "no exception raised")
except ValueError as exc:
    check("declared group without operations is rejected",
          "symmetry operations" in str(exc), "got %r" % str(exc)[:80])
os.remove(bad_cif)

# a symmetric file WITH operations expands and reports the expansion
sym_cif = os.path.join(HERE, "_tmp_sym.cif")
with io.open(sym_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_sym
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
_symmetry_space_group_name_H-M 'P -1'
loop_
_symmetry_equiv_pos_as_xyz
'x, y, z'
'-x, -y, -z'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
s_sym = read_cif(sym_cif)
check("expanded file doubles the site", s_sym.natoms == 2, "got %d" % s_sym.natoms)
check("expansion note records what happened",
      "1 sites x 2 operations" in s_sym.expansion_note,
      "got %r" % s_sym.expansion_note)
os.remove(sym_cif)

# an explicit P1 file without operations passes through without a note
p1_cif = os.path.join(HERE, "_tmp_p1.cif")
with io.open(p1_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_p1
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
check("explicit P1 without operations reads cleanly",
      read_cif(p1_cif).expansion_note == "")
os.remove(p1_cif)

# --------------------------------------------------------------------- #
print("")
print("%d checks, %d failure(s)" % (_checks, len(_failures)))
for f in _failures:
    print("   FAILED: %s" % f)
sys.exit(1 if _failures else 0)
