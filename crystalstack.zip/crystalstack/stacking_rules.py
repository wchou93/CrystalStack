# -*- coding: utf-8 -*-
"""Offset rules for 2D layer stacking, recovered from the reference structures.

The two stacking offsets used in this work are defined as follows.

AA' offset (serrated / inclined stacking)
    The in-plane vector by which layer 2 is displaced relative to layer 1 in a
    *slipped* stack.  Expressed in **fractional** coordinates it takes the same
    exact value for every hexagonal COF studied here::

        delta = (2/15, 1/15)  of  (a, b)

    This single vector reproduces the measured offset of COF-1 to 0.013 A and
    of CTF-1 to 0.027 A.  Because **b** sits at 120 degrees, the Cartesian
    direction is exactly **30 degrees from a** — the slip direction seen in the
    reference data.  Its magnitude is ``sqrt(3)/15 |a| = 0.115470 |a|``, i.e.
    ~1.73 A for a 14.5-15.0 A cell.  (Not to be confused with ``0.1146``,
    which is the *measured* COF-1 offset over its cell -- 1.7157 / 14.9640 --
    and not a rounding of this constant: this constant rounds to 0.1155.)

    Measured AA' offsets in the reference data set:

    ==========  ==========  ===========  ============  =====================
    system      a (A)       direction    magnitude     fractional (a, b)
    ==========  ==========  ===========  ============  =====================
    COF-1       14.964      29.88 deg    1.7157 A      (0.13239, 0.06596)
    COF-5       30.020       0.0 deg     1.5999 A      (0.05329, 0.00000)
    CTF-1       14.521      30.87 deg    1.6705 A      (0.13285, 0.06821)
    Pc-PBBA     22.915      30.4 deg     1.5989 A      (0.06018, 0.03532)
    ==========  ==========  ===========  ============  =====================

    **COF-5 is an exception**: it slides along **a** (0 degrees) rather than at
    30 degrees, so its fractional offset does not follow the rule above.  The
    slip direction follows the linker geometry, and COF-5 has a different
    linker from COF-1 and CTF-1.  It is therefore supplied explicitly rather
    than predicted.

    Note also that the magnitude is *not* proportional to the lattice constant
    in the naive sense — it is the *fraction* that is constant.  For a larger
    cell such as COF-5 the same fraction would give 3.44 A, which is why the
    rule must never be applied to COF-5.

AB offset (staggered stacking)
    The vector that moves one layer onto the **pore centre** of the next.  For
    a hexagonal monolayer this is the (2/3, 1/3)-type position; for a square
    monolayer it is (1/2, 1/2).  Measured and verified against every reference
    staggered structure.

How the offsets are determined
------------------------------

AA' is *not* found by minimising any geometric objective.  Two apparently
natural objectives were tried and both are degenerate:

* **largest nearest-neighbour displacement** — for any offset shorter than the
  shortest interatomic distance every atom finds its own periodic image first,
  so the value collapses to ``|offset|`` and has no minimum at the stacking
  position;
* **minimum interlayer separation** — the same self-image dominates, so the
  value is again monotone in ``|offset|``.

The offset is a position on the interlayer potential-energy surface, so it is
either taken from the exact fractional rule above (the automatic path, with
COF-5 supplied explicitly) or supplied by the caller from a PES scan.

AB *is* found geometrically: the pore centre is the point maximising the
distance to the nearest framework atom, and among the high-symmetry candidates
the winner is unambiguous because it clears the framework by an order of
magnitude more than any alternative.
"""

from __future__ import annotations

from typing import List, Sequence, Tuple

import numpy as np
from scipy.spatial import KDTree

__all__ = [
    "PLANE_GROUP_OPS",
    "CANDIDATE_AXIS_SHIFTS",
    "CANDIDATE_PORE_SHIFTS",
    "SYMMETRY_OPS",
    "DEFAULT_SYMMETRY_OP",
    "pbc_shifts",
]

#: In-plane symmetry operations, as ``(label, 2x2 matrix)`` acting on
#: fractional in-plane coordinates from the left.
PLANE_GROUP_OPS: Tuple[Tuple[str, np.ndarray], ...] = (
    ("E", np.eye(2)),
    ("C2", -np.eye(2)),
    ("C3", np.array([[0.0, -1.0], [1.0, -1.0]])),
    ("C3^2", np.array([[-1.0, 1.0], [-1.0, 0.0]])),
    ("m_x", np.array([[-1.0, 0.0], [0.0, 1.0]])),
    ("m_y", np.array([[1.0, 0.0], [0.0, -1.0]])),
    ("m_d", np.array([[0.0, 1.0], [1.0, 0.0]])),
    ("m_d'", np.array([[0.0, -1.0], [-1.0, 0.0]])),
)

#: Fractional positions at which a rotation or mirror axis may sit.  Covers
#: the special positions of the hexagonal (p3, p6, c2mm) and the square
#: (p4, p4mm) plane groups.
CANDIDATE_AXIS_SHIFTS: Tuple[Tuple[float, float], ...] = (
    (0.0, 0.0),
    (1 / 3, 1 / 3), (2 / 3, 2 / 3),
    (1 / 3, 2 / 3), (2 / 3, 1 / 3),
    (1 / 2, 0.0), (0.0, 1 / 2), (1 / 2, 1 / 2),
    (1 / 2, 1 / 3), (1 / 3, 1 / 2),
    (1 / 2, 2 / 3), (2 / 3, 1 / 2),
    (1 / 6, 1 / 6), (5 / 6, 5 / 6),
    (1 / 6, 5 / 6), (5 / 6, 1 / 6),
)

#: Fractional positions of the pore centres (AB stacking vectors).
CANDIDATE_PORE_SHIFTS: Tuple[Tuple[float, float], ...] = (
    (2 / 3, 1 / 3), (1 / 3, 2 / 3),
    (1 / 2, 1 / 2),
    (1 / 2, 0.0), (0.0, 1 / 2),
    (1 / 3, 1 / 3), (2 / 3, 2 / 3),
)

#: The pore centre of a **hexagonal** monolayer, in fractional coordinates.
#: On a hexagonal cell the largest void of a p6mm/p3 network sits at the
#: three-fold position ``(2/3, 1/3)`` — equivalently ``(1/3, 2/3)``, which is
#: the same point translated by a lattice vector.  Verified against COF-1,
#: COF-5 and CTF-1: in all three the measured staggered offset is this vector.
#:
#: .. warning::
#:
#:    This must be chosen by **lattice type**, not by ranking candidates on
#:    their clearance.  The clearance is not a reliable discriminator: in COF-5
#:    the true ``(2/3, 1/3)`` pore clears the framework by only 0.016 A, while
#:    the non-pore ``(1/3, 1/3)`` clears by 0.073 A — an earlier version that
#:    sorted by clearance therefore picked the wrong vector for COF-5 and for
#:    the square Pc-PBBA cell.
PORE_FRACTIONAL_HEXAGONAL: Tuple[float, float] = (2.0 / 3.0, 1.0 / 3.0)

#: The pore centre of a **square** monolayer.  ``(1/2, 1/2)`` is the four-fold
#: special position of p4mm; verified against Pc-PBBA, whose measured staggered
#: offset is exactly this vector.
PORE_FRACTIONAL_SQUARE: Tuple[float, float] = (0.5, 0.5)

#: Symmetry operations that relate layer 2 to layer 1 in the ``rotated``
#: stacking mode (output form **(e)**), as ``(key, label, 2x2 matrix)``.
#:
#: The matrix acts on **fractional in-plane column vectors**, i.e.
#: ``(x', y')^T = M (x, y)^T``.  Layer 2 is then
#: ``op(layer1) + (0, 0, 0.5)`` — the half-cell translation placing it in the
#: second half of the doubled **c** axis.  No extra in-plane translation is
#: required by any of these operations.
#:
#: Which operation is right
#: ------------------------
#: For the reference system supplied alongside this work (the example bilayer:
#: Cu12 N24 H12 C12, a = b = 12.191 A, gamma = 120 deg, c = 6.7047 A) the
#: relation was recovered from the raw file and is **exact**:
#:
#: ====================  ==========================  ============
#: operation             matrix (fractional)         max error
#: ====================  ==========================  ============
#: **transpose**         ``[[0,1],[1,0]]``           **0.000000**
#: identity               ``[[1,0],[0,1]]``           1.500332
#: inversion             ``[[-1,0],[0,-1]]``         1.500332
#: mirror x              ``[[1,0],[0,-1]]``          2.029684
#: mirror y              ``[[-1,0],[0,1]]``          2.029684
#: rotation 120          ``[[0,-1],[1,-1]]``         1.500332
#: rotation 180          ``[[-1,0],[0,-1]]``         1.500332
#: ====================  ==========================  ============
#:
#: Only the transposition reproduces the reference structure; everything else
#: is off by more than 1.5 A.  :data:`DEFAULT_SYMMETRY_OP` is therefore
#: ``"transpose"``.  The others are offered so that alternative symmetries can
#: be compared, but they are *not* validated against any reference.
#:
#: Validation (important)
#: ----------------------
#: All of these operations are applied about the **fractional origin** unless
#: :meth:`layer_stacking.LayerStackingEngine.build_rotated` finds a better
#: axis.  Whether an operation is a symmetry operation of the layer at all
#: depends on where the layer's own axes sit, and that differs from material
#: to material: the transposition is exact for COF-5 but fails for COF-1
#: (whose axes sit at (1/6, 5/6)-type positions), and the buckled CTF-1 layer
#: has no exact operation at all.  The engine therefore measures the residual
#: (the largest same-species PBC displacement the operation produces) before
#: the structure is accepted, searches :data:`CANDIDATE_AXIS_SHIFTS` for an
#: axis the operation does hold about, and warns loudly when nothing
#: validates -- a silent wrong stacking is the one failure mode this tool
#: must never produce.
SYMMETRY_OPS: Tuple[Tuple[str, str, np.ndarray], ...] = (
    ("transpose", "transpose (x<->y)", np.array([[0.0, 1.0], [1.0, 0.0]])),
    ("identity", "identity", np.eye(2)),
    ("inversion", "inversion", -np.eye(2)),
    ("mirror_x", "mirror x", np.array([[1.0, 0.0], [0.0, -1.0]])),
    ("mirror_y", "mirror y", np.array([[-1.0, 0.0], [0.0, 1.0]])),
    ("rot60", "rotation 60 deg", np.array([[1.0, -1.0], [1.0, 0.0]])),
    ("rot120", "rotation 120 deg", np.array([[0.0, -1.0], [1.0, -1.0]])),
    ("rot180", "rotation 180 deg", np.array([[-1.0, 0.0], [0.0, -1.0]])),
    ("rot300", "rotation 300 deg", np.array([[0.0, 1.0], [-1.0, 1.0]])),
)

#: The symmetry operation verified against the reference structure.
DEFAULT_SYMMETRY_OP: str = "transpose"

#: The half-cell translation applied along **c** to place layer 2.
SYMMETRY_LAYER_SHIFT: float = 0.5


def symmetry_op(key: str) -> np.ndarray:
    """Return the 2x2 fractional matrix for ``key``.

    Raises
    ------
    KeyError
        If ``key`` is not a known operation.
    """
    for k, _label, mat in SYMMETRY_OPS:
        if k == key:
            return mat.copy()
    raise KeyError(
        "unknown symmetry operation %r; known: %s"
        % (key, ", ".join(k for k, _l, _m in SYMMETRY_OPS))
    )


def pbc_shifts(n: int = 1) -> np.ndarray:
    """``(2n+1)^2`` in-plane periodic images, as an array of fractional shifts."""
    rng = range(-n, n + 1)
    return np.array([[i, j] for i in rng for j in rng], dtype=float)
